<?php

/*

//include('code/classes/getfiles_in_folder.php'); 

//$images = new DirectoryItems('download/pdf-books/');

  function DirectoryItems($directory){
		$d = '';
  	if(is_dir($directory))
		{
  		$d = opendir($directory) or die("Couldn't open directory.");
  		while(false !== ($f = readdir($d)))
			{
    		if(is_file("$directory/$f"))
				{
					print_r($f.'<BR>');
    		}
  		}
			closedir($d);
		}else{
			//error
			die('Must pass in a directory.');
		}
	}
  

$getit = DirectoryItems('download/pdf-books/');


*/

echo 'getfiles';
class DirectoryItems{

	//data members
	var $filearray = array();
	var $images = array();

////////////////////////////////////////////////////////////////////
//constructor
////////////////////////////////////////////////////////////////////
  function DirectoryItems($directory){
		$d = '';
  	if(is_dir($directory))
		{
  		$d = opendir($directory) or die("Couldn't open directory.");
  		while(false !== ($f = readdir($d)))
			{
    		if(is_file("$directory/$f"))
				{
					$this->filearray[]=$f;
    		}
  		}
			closedir($d);
		}else{
			//error
			die('Must pass in a directory.');
		}
	}
////////////////////////////////////////////////////////////////////
//public functions
////////////////////////////////////////////////////////////////////
	function indexOrder(){
		sort($this->filearray);
	}
////////////////////////////////////////////////////////////////////
	function naturalCaseInsensitiveOrder(){
		natcasesort($this->filearray);
	}
////////////////////////////////////////////////////////////////////
	function checkAllImages(){
		$bln=true;
		$extension='';
		$types= array('jpg', 'jpeg', 'gif', 'png', 'db', 'pdf', 'txt');
		foreach ($this->filearray as $value){
			$extension = substr($value,(strpos($value, ".")+1));
			$extension = strtolower($extension);
			if(!in_array($extension, $types)){
				$bln = false;
				break;
			}
		}
		return $bln;
	}
////////////////////////////////////////////////////////////////////
	function getCount() {
		return count($this->filearray);
	}
////////////////////////////////////////////////////////////////////
	function getFileArray(){
		return $this->filearray;
	}
	
	function getImages($table) {

  /*
	$sql="SELECT * FROM ".$table." "; 
	$resultcheck = mysql_query($sql) or die("<b>ERROR:</b> " . mysql_error());
	while ($row = mysql_fetch_object($resultcheck)) {
	
	if ($table == "business_site2"){ 
	array_push ($this->images, $row->logo);
	array_push ($this->images, $row->slogan);
	array_push ($this->images, $row->photo1);
	array_push ($this->images, $row->photo2);
	array_push ($this->images, $row->photo3);
	array_push ($this->images, $row->business_logo);
	array_push ($this->images, $row->default_photo);
	array_push ($this->images, $row->area1);
	array_push ($this->images, $row->area2);
	array_push ($this->images, $row->area3);
	} else {
	
	array_push ($this->images, $row->photo);
	
	}
  */
  	array_push ($this->images, $row->photo);
	
	return $this->images;
}
}//end class
////////////////////////////////////////////////////////////////////


	
	
?>

