<?php


// replace unwanted characters with space
function stringreplace($var){

  $remove = array('&quot;', '/', '(',  ')', '.', ',', ';', ':', '&', '?', '�', '�',' ', '*', '!', '', '_', '"', '$', '%', '}', '{', '@', '+', '^', '___', '�', '&nbsp;', '�', '�');
  $var = str_replace($remove, " ", $var);
  $var = str_replace("'", "", $var);
  
  return $var;

}

// replaces unwanted characters with dash for url purposes
function cleanurl($var){

  $remove = array('&quot;', '/', '(',  ')', '.', ',', ';', ':', '&', '?', '�', '�',' ', '*', '!', '', '_', '"', '$', '%', '}', '{', '@', '+', '^', '___', '�');
  
  $var = trim($var);
  $var = str_replace($remove, "-", $var);
  $var = strtolower($var);
  $var = str_replace("'", "-", $var);
  $var = str_replace("___", "-", $var);
  $var = str_replace("---", "-", $var);
  $var = str_replace("--", "-", $var);
  
  
  return $var;

}


function clean_inputs() { 
foreach ($_POST as $key => $value) { $_POST[$key] = htmlentities(trim($value), ENT_QUOTES); } 	
}

function sanitizehtml($html){
    
  $html_reg = '/<+\s*\/*\s*([A-Z][A-Z0-9]*)\b[^>]*\/*\s*>+/i';
  $html_a = htmlentities( preg_replace( $html_reg, '', $html ) );

   
  $html_b = mysql_real_escape_string($html_a);
 
  
  return $html_b;
  
}

function replacequotes($var){

  $var = str_replace("'", "&#39;", $var);
  return $var;

}

function percent($amount, $percentage) {
$count1 = $amount / 100;
$count2 = $count1 * $percentage;
return $count2;
}


function cleannumber($var) {
  $remove = array(',', '.');
  $var = str_replace($remove, "", $var);
  return $var;
}

	function currencyconverter($from_Currency,$to_Currency,$amount) {
    $amount = urlencode($amount);
    $from_Currency = urlencode($from_Currency);
    $to_Currency = urlencode($to_Currency);
    $get = file_get_contents("https://www.google.com/finance/converter?a=$amount&from=$from_Currency&to=$to_Currency");
    $get = explode("<span class=bld>",$get);
    $get = explode("</span>",$get[1]);  
    $converted_amount = preg_replace("/[^0-9\.]/", null, $get[0]);
    return $converted_amount;
}

function cutDesc($string)
{
$string = substr($string, 0, 200);
$find =  array("<BR>", "<br>", "</ BR>", "</ br>", "<p>", "</p>");
$replace =  array("", "", "", "", "", "");
$string = str_replace($find, '', $string);
$string = trim ($string);
return $string;
}

/*
PHP class Google Currency Converter
Feb 06 2009
webmaster@chazzuka.com
*/
/*
class GoogleCurrencyConverter
{
// GOOGLE URL
CONST GOOGLE_URL = "http://finance.google.com/finance/converter?a=%d&amp;from=%s&amp;to=%s";
/*
Fetch with CURL
params: amount, 3 Digit Currency Code From,3 Digit Currency Code to
*/
/*
private function load($a,$from,$to)
{
$ch = curl_init ();
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_URL, sprintf(self::GOOGLE_URL,$a,$from,$to));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
$response = curl_exec($ch);
curl_close($ch);
return $response;
}
/*
Try to Convert
params: amount, 3 Digit Currency Code From,3 Digit Currency Code to
*/
/*
public static function convert($from,$to,$a)
{
$response = self::load($a,$from,$to);
$return_value = false;
if($response) {
if (preg_match("%
<div id="currency_converter_result">([\d.]+) ".$from." = <span class="[^">]*&gt;([\d.]+) ".$to."</span>%s", $response, $matches)) {
$return_value = $matches[2];
}
}
return $return_value;
}
}
 */
?>