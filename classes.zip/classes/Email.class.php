<?PHP

class email {

var $to;
var $from;
var $subject;
var $body;

function validateEmail($email){

	$regexp ="^([_a-z0-9-]+)(\.[_a-z0-9-]+)*@([a-z0-9-]+)(\.[a-z0-9-]+)*(\.[a-z]{2,4})$";
	if (eregi($regexp, $email)){return true;} else { return false;}	
	}
  
  /*
  function validateEmail($email){

	if(!preg_match("/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/i", $str)) {
	return true;} else { return false;}	

 }
 */

function sendMail( $to, $from, $subject, $body ) {

		
	if ($this->validateEmail($to) == false){return false;} 
	if ($this->validateEmail($from) == false){return false;}
	$body=stripslashes($body);
	$subject=stripslashes($subject);

$headers = 'From: '.$from.'' . "\r\n".
'Reply-To: '.$from.''. "\r\n".
'Return-Path: '.$from.'' . "\r\n".
'X-Mailer: PHP/' . phpversion();

	if (mail ($to, $subject, $body, $headers, '-f $from')){return true;} else { 
	return false;
	}
}
}
/*
$headers = "MIME-Version: 1.0\n";
$headers .= "Content-type: text/html; charset=iso-8859-1\n";
$headers = "From: ".$from."\n";

*/
?>