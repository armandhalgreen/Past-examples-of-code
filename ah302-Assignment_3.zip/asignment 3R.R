# Assignment 3 ah302
# I confirm that the following report and associated code is my own work, except where clearly indicated

# LOads packages 
install.packages("dslabs") 
library("dslabs")

# Choose dataset
data <- admissions

# Set seed
set.seed(101)

# Separate data into two vectors. One vector for males and one vector for females
datamales <- c()
datafemales <- c()
for (i in 1:length(data$gender)){
  if (data$gender[i]=="men")
  {datamales <- append(datamales,(data$admitted[i])/(data$applicants[i]))}
  else {datafemales <- append(datafemales,(data$admitted[i])/(data$applicants[i]))}
}

# Remove outlier
datamales<- datamales[-2]
datafemales<- datafemales[-2]

# Scenario 1 differing sigma
i1 <- c()
power_ttest1 <- c()
power_wilcox1 <- c()
size_ttest1 <- c()
size_wilcox1 <- c()
datamales1 <- c()
datafemales1 <- c()
datamales2 <- c()
datafemales2 <- c()
a=0.05
n=100 

# Calculate data for scenario 1 power using rnorm with mean and sd from the original data for males and females
datamales1 <- append(datamales1,abs(rnorm(n,mean=mean(datamales),sd=sqrt(var(datamales)))))
datafemales1 <- append(datafemales1,abs(rnorm(n,mean=mean(datafemales),sd=sqrt(var(datafemales)))))

# Calculate data for scenario 1 size using rnorm with mean and sd from the original data for males and females
datamales2 <- append(datamales2,abs(rnorm(n,mean=mean(mean(datamales)+mean(datafemales)),sd=sqrt(var(datamales)))))
datafemales2 <- append(datafemales2,abs(rnorm(n,mean=mean(mean(datamales)+mean(datafemales)),sd=sqrt(var(datamales)))))


for (j in 1:10){
d=0.001+0.01*j-0.01
i1 <- append(i1,d)

# Size t test function
size_ttest_function <- function(datamales,datafemales,a,d){
  n=100
  set.seed(101)
  # simulate p values
  pval <- replicate(n, t.test(rnorm(n,mean=mean(datamales),sd=d), rnorm(n,mean=mean(datafemales),sd=d))$p.value) 
  size <- 0
  for (i in 1:n){
    if (pval[i] < a){
      size <- (1.0/n) +size
    }
  }
  return(size)
}

# Size wilcox function
size_wilcox_function <- function(datamales,datafemales,a,d){
  n=100
  set.seed(101)
  # simulate p values
  pval <- replicate(n, wilcox.test(rnorm(n,mean=mean(datamales),sd=d), rnorm(n,mean=mean(datafemales),sd=d))$p.value) 
  size <- 0
  for (i in 1:n){
    if (pval[i] < a){
      size <- (1.0/n) +size
    }
  }
  return(size)
}

# Power ttest function
power_ttest_function <- function(datamales,datafemales,a,d){
  n=100
  d=d*20.0
  set.seed(101)
  # simulate p values
  pval <- replicate(n, t.test(rnorm(n,mean=mean(datamales),sd=d), rnorm(n,mean=mean(datafemales),sd=d))$p.value) 
  power <- (sum(pval < a))/n
  return(power)
}

# Power wilcox function
power_wilcox_function <- function(datamales,datafemales,a,d){
  n=100
  d=d*20
  set.seed(101)
  pval <- replicate(n, wilcox.test(rnorm(n,mean=mean(datamales),sd=d), rnorm(n,mean=mean(datafemales),sd=d))$p.value) 
  power <- (sum(pval < a))/n
  return(power)
}

# Calculate size of t test
size_ttest1 <- append(size_ttest1,size_ttest_function(datamales2,datafemales2,a,d))

# Calculate size of wilcox test
size_wilcox1 <- append(size_wilcox1,size_wilcox_function(datamales2,datafemales2,a,d))

# Calculate power of t test
power_ttest1 <- append(power_ttest1,power_ttest_function(datamales1,datafemales1,a,d))

# Calculate power of wilcox test
power_wilcox1 <- append(power_wilcox1,power_wilcox_function(datamales1,datafemales1,a,d))

# Create a plot of n vs size of t test
#plot(i1,size_ttest1,col="blue",main="sigma vs size of t test",xlab="sigma",ylab="size of t test")
#lines(i1,size_ttest1)

# Create a plot of n vs size of wilcox test
#plot(i1,size_wilcox1,col="blue",main="sigma vs size of wilcox test",xlab="sigma",ylab="size of wilcox test")
#lines(i1,size_wilcox1)

# Create a plot of n vs power of t test
#plot(i1,power_ttest1,col="blue",main="sigma vs power of t test",xlab="sigma",ylab="power of t test")
#lines(i1,power_ttest1)

# Create a plot of n vs power of wilcox test
plot(i1,power_wilcox1,col="blue",main="sigma vs power of wilcox test",xlab="sigma",ylab="power of wilcox test")
lines(i1,power_wilcox1)
}









# Scenario 2 differing numbers of admitted/applicants

# Size t test function
size_ttest_function <- function(datamales,datafemales,a){
  n=100
  set.seed(101)
  # simulate p values
  pval <- replicate(n, t.test(rnorm(n,mean=mean(datamales),sd=0.2), rnorm(n,mean=mean(datafemales),sd=0.2))$p.value) 
  size <- 0
  for (i in 1:n){
    if (pval[i] < a){
      size <- (1.0/n) +size
    }
  }
  return(size)
}

# Size wilcox function
size_wilcox_function <- function(datamales,datafemales,a){
  n=100
  set.seed(101)
  # simulate p values
  pval <- replicate(n, wilcox.test(rnorm(n,mean=mean(datamales),sd=0.5), rnorm(n,mean=mean(datafemales),sd=0.5))$p.value) 
  size <- 0
  for (i in 1:n){
    if (pval[i] < a){
      size <- (1.0/n) +size
    }
  }
  return(size)
}

# Power ttest function
power_ttest_function <- function(datamales,datafemales,a){
  n=100
  set.seed(101)
  # simulate p values
  pval <- replicate(n, t.test(rnorm(n,mean=mean(datamales),sd=sqrt(var(datamales))), rnorm(n,mean=mean(datafemales),sd=sqrt(var(datafemales))))$p.value) 
  power <- (sum(pval < a))/n
  return(power)
}

# Power wilcox function
power_wilcox_function <- function(datamales,datafemales,a){
  n=100
  set.seed(101)
  # simulate p values
  pval <- replicate(n, wilcox.test(rnorm(n,mean(datamales),sqrt(var(datamales))), rnorm(n,mean(datafemales),sqrt(var(datafemales))))$p.value) 
  power <- (sum(pval < a))/n
  return(power)
}

# Set empty vectors required for the scenario
n2 <- c()
power_ttest1 <- c()
power_wilcox1 <- c()
size_ttest1 <- c()
size_wilcox1 <- c()
ttest1 <- c()
wilcoxtest1 <- c()

for (i in 1:50){
  
  # Set empty vectors required for the scenario
  datamales1 <- c()
  datafemales1 <- c()
  datamales2 <- c()
  datafemales2 <- c()

  # Set n and append it to a vector
  n1=i*2
  n2 <- append(n2,n1)
  
  # Set the seed
  set.seed(101)
  
  # Set a level 
  a=0.1
  
  # Calculate data for scenario 1 power using rnorm with mean and sd from the original data for males and females
  datamales1 <- append(datamales1,abs(rnorm(n1,mean=mean(datamales),sd=sqrt(var(datamales)))))
  datafemales1 <- append(datafemales1,abs(rnorm(n1,mean=mean(datafemales),sd=sqrt(var(datafemales)))))
  
  # Calculate data for scenario 1 size using rnorm with mean and sd from the original data for males and females
  datamales2 <- append(datamales2,abs(rnorm(n1,mean=mean(mean(datamales)+mean(datafemales)),sd=sqrt(var(datamales)))))
  datafemales2 <- append(datafemales2,abs(rnorm(n1,mean=mean(mean(datamales)+mean(datafemales)),sd=sqrt(var(datamales)))))
  
  
  #   Perform t test and wilcox test
  ttest1 <- append(ttest1,t.test(datamales1,datafemales1))
  wilcoxtest1 <- append(wilcoxtest1,wilcox.test(datamales1,datafemales1))
  
  # Calculate size of t test
  size_ttest1 <- append(size_ttest1,size_ttest_function(datamales2,datafemales2,a))
  
  # Calculate size of wilcox test
  size_wilcox1 <- append(size_wilcox1,size_wilcox_function(datamales2,datafemales2,a))
  
  # Calculate power of t test
  power_ttest1 <- append(power_ttest1,power_ttest_function(datamales1,datafemales1,a))
  
  # Calculate power of wilcox test
  power_wilcox1 <- append(power_wilcox1,power_wilcox_function(datamales1,datafemales1,a))
  
  # Create a plot of n vs size of t test
  #plot(n2,size_ttest1,col="blue",main="n vs size of t test",xlab="sample size",ylab="size of t test")
  #lines(n2,size_ttest1)
  
  # Create a plot of n vs size of wilcox test
  #plot(n2,size_wilcox1,col="blue",main="n vs size of wilcox test",xlab="sample size",ylab="size of wilcox test")
  #lines(n2,size_wilcox1)
  
  # Create a plot of n vs power of t test
  #plot(n2,power_ttest1,col="blue",main="n vs power of t test",xlab="sample size",ylab="power of t test")
  #lines(n2,power_ttest1)
  
  # Create a plot of n vs power of wilcox test
  plot(n2,power_wilcox1,col="blue",main="n vs power of wilcox test",xlab="sample size",ylab="power of wilcox test")
  lines(n2,power_wilcox1)
}












# Scenario 3 round the datapoints to different decimal places
i1 <- c()
power_ttest1 <- c()
power_wilcox1 <- c()
size_ttest1 <- c()
size_wilcox1 <- c()
datamales1 <- c()
datafemales1 <- c()
datamales2 <- c()
datafemales2 <- c()
a=0.1
n=100

# Calculate data for scenario 1 power using rnorm with mean and sd from the original data for males and females
datamales1 <- append(datamales1,abs(rnorm(n,mean=mean(datamales),sd=sqrt(var(datamales)))))
datafemales1 <- append(datafemales1,abs(rnorm(n,mean=mean(datafemales),sd=sqrt(var(datafemales)))))

# Calculate data for scenario 1 size using rnorm with mean and sd from the original data for males and females
datamales2 <- append(datamales2,abs(rnorm(n,mean=mean(mean(datamales)+mean(datafemales)),sd=sqrt(var(datamales)))))
datafemales2 <- append(datafemales2,abs(rnorm(n,mean=mean(mean(datamales)+mean(datafemales)),sd=sqrt(var(datamales)))))


for (j in 1:10){
  r=j
  i1 <- append(i1,r)
  
  # Size t test function
  size_ttest_function <- function(datamales,datafemales,a,d){
    n=100
    set.seed(101)
    # simulate p values
    pval <- round(replicate(n, t.test(rnorm(n,mean=mean(datamales),sd=d), rnorm(n,mean=mean(datafemales),sd=d))$p.value),digits = r) 
    size <- 0
    for (i in 1:n){
      if (pval[i] < a){
        size <- (1.0/n) +size
      }
    }
    return(size)
  }
  
print (size_ttest_function(datamales2,datafemales2,0.1,0.02))
  
  # Size wilcox function
  size_wilcox_function <- function(datamales,datafemales,a,d){
    n=100
    set.seed(101)
    # simulate p values
    pval <- round(replicate(n, wilcox.test(rnorm(n,mean=mean(datamales),sd=d), rnorm(n,mean=mean(datafemales),sd=d))$p.value),digits = r) 
    size <- 0
    for (i in 1:n){
      if (pval[i] < a){
        size <- (1.0/n) +size
      }
    }
    return(size)
  }
  
  # Power ttest function
  power_ttest_function <- function(datamales,datafemales,a,d){
    n=100
    d=d*20.0
    set.seed(101)
    # simulate p values
    pval <- round(replicate(n, t.test(rnorm(n,mean=mean(datamales),sd=d), rnorm(n,mean=mean(datafemales),sd=d))$p.value),digits = r)
    power <- (sum(pval < a))/n
    return(power)
  }
  
  # Power wilcox function
  power_wilcox_function <- function(datamales,datafemales,a,d){
    n=100
    d=d*20
    set.seed(101)
    # simulate p values
    pval <- round(replicate(n, wilcox.test(rnorm(n,mean=mean(datamales),sd=d), rnorm(n,mean=mean(datafemales),sd=d))$p.value),digits = r)
    power <- (sum(pval < a))/n
    return(power)
  }
  
  # Calculate size of t test
  size_ttest1 <- append(size_ttest1,size_ttest_function(datamales2,datafemales2,a,0.02))
  
  # Calculate size of wilcox test
  size_wilcox1 <- append(size_wilcox1,size_wilcox_function(datamales2,datafemales2,a,0.02))
  

  # Calculate power of t test
  power_ttest1 <- append(power_ttest1,power_ttest_function(datamales1,datafemales1,a,0.02))
  
  # Calculate power of wilcox test
  power_wilcox1 <- append(power_wilcox1,power_wilcox_function(datamales1,datafemales1,a,0.02))
  
  # Create a plot of n vs size of t test
  #plot(i1,size_ttest1,col="blue",main="number of decimal places vs size of t test",xlab="number of decimal places",ylab="size of t test")
  #lines(i1,size_ttest1)
  
  # Create a plot of n vs size of wilcox test
  #plot(i1,size_wilcox1,col="blue",main="number of decimal places vs size of wilcox test",xlab="number of decimal places",ylab="size of wilcox test")
  #lines(i1,size_wilcox1)
  
  # Create a plot of n vs power of t test
  #plot(i1,power_ttest1,col="blue",main="number of decimal places vs power of t test",xlab="number of decimal places",ylab="power of t test")
  #lines(i1,power_ttest1)
  
  # Create a plot of n vs power of wilcox test
  plot(i1,power_wilcox1,col="blue",main="number of decimal places vs power of wilcox test",xlab="number of decimal places",ylab="power of wilcox test")
  lines(i1,power_wilcox1)
}

