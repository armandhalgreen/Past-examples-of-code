<?php
 require_once ('core/app.php');
 require_once ('core/controller.php');
 
 $app=new app;
?>

