<?php

class user{

public $name;

}

?>