Hello

<?php

echo ($data['name']);

?>