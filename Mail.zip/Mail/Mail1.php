<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer-6.1.7/src/Exception.php';
require 'PHPMailer-6.1.7/src/PHPMailer.php';
require 'PHPMailer-6.1.7/src/SMTP.php';

$from="armandhalgreen@gmail.com";
$to="armandhalgreen11001@gmail.com";
$subject='hi';
$message='hi';

$mail = new PHPMailer();
$mail->IsSendmail();
$mail->Host = "smtp.gmail.com";

$mail->SetFrom($from, $from);
$mail->AddAddress($to);

$mail->Subject = $subject;
$mail->Body = $message;
var_dump($mail->Send());


echo 'hi';
?>