<?php

//error_reporting(-1);
//ini_set('display_errors', 'On');
//set_error_handler("var_dump");


//$message = 'hi';
//$from = 'From: armandhalgreen@gmail.com';
//$to = 'armandhalgreen11001@gmail.com';
//$subject = 'Customer Inquiry';
//$body = "hi";

//if (mail ($to, $subject, $body)) {
    //echo '<p>Your message has been sent!</p>';

//} else {
//    echo '<p>Something went wrong, go back and try again!</p>';
//}

//$mail='armandhalgreen11001@gmail.com'  ;


//if (mail($mail, 'Subject', 'sample mail')) {
  //  echo '<p>Your message has been sent!</p>';

//} else {
  //  var_dump(mail($mail, 'Subject', 'sample mail'));
//}

?>

<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'path/to/PHPMailer/src/Exception.php';
require 'path/to/PHPMailer/src/PHPMailer.php';
require 'path/to/PHPMailer/src/SMTP.php';


$mail = new PHPMailer;
$mail->isSMTP();                            // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com';              // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                     // Enable SMTP authentication
$mail->Username = 'example@gmail.com'; // your email id
$mail->Password = 'password'; // your password
$mail->SMTPSecure = 'tls';                  
$mail->Port = 587;     //587 is used for Outgoing Mail (SMTP) Server.
$mail->setFrom('sendfrom@gmail.com', 'Name');
$mail->addAddress('sendto@yahoo.com');   // Add a recipient
$mail->isHTML(true);  // Set email format to HTML

$bodyContent = '<h1>HeY!,</h1>';
$bodyContent .= '<p>This is a email that Radhika send you From LocalHost using PHPMailer</p>';
$mail->Subject = 'Email from Localhost by Radhika';
$mail->Body    = $bodyContent;
if(!$mail->send()) {
  echo 'Message was not sent.';
  echo 'Mailer error: ' . $mail->ErrorInfo;
} else {
  echo 'Message has been sent.';
}

?>