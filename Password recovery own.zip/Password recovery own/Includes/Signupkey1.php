<?php


if(isset($_POST["submitkey"])){
$username=$_POST["username"];
$email=$_POST["email"];
$key=$_POST["key"];
$enteredkey=$_POST["enteredkey"];

require 'dbh.php';

if(password_verify($enteredkey, $key)){
header("Location: Signup1.php?add=database");
exit();
}

else{
header("Location: ../Signupkey.php?resend=key&username=".$username."&email=".$email."&key=".$key);
exit();
}

mysqli_close($conn);
}


if(isset($_POST["resendkey"])){
$username=$_POST["username"];
$email=$_POST["email"];
$key=rand(1, 1000000);
mail($email,"Key",$key);
$key=password_hash($key, PASSWORD_DEFAULT);
header("Location: ../Signupkey.php?username=".$username."&email=".$email."&key=".$key);
exit();
}

?>