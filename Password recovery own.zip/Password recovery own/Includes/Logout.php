<?php
if(isset($_POST["logout-submit"])){
header("Location: ../Registrationform.php?");
}

?>