<?php

$username=$_POST["username"];
$password=$_POST["password"];

if(isset($_POST["login-submit"])){

if (strlen($username)==0||strlen($password)==0){
header("Location: ../Login.php?login=fail");
exit();
}

else{

require 'dbh.php';


$sql="SELECT * FROM users WHERE uidUsers=?";
$stmt=mysqli_stmt_init($conn);
mysqli_stmt_prepare($stmt,$sql);
mysqli_stmt_bind_param($stmt,"s",$username);
mysqli_stmt_execute($stmt);
mysqli_stmt_store_result($stmt);
$result=mysqli_stmt_get_result($stmt);
$resultCheck=mysqli_stmt_num_rows($stmt);

$stmt = $conn->stmt_init();
$stmt->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_array(MYSQLI_NUM);

if($row[1]==$username & $row[3]==$password){   
header("Location: ../Login.php?login=success");
$result->free();
}

else{
header("Location: ../Login.php?login=fail");
}

}
mysqli_close($conn);
}

?>