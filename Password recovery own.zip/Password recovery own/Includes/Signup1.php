<?php

$username=$_POST["username"];
$email=$_POST["email"];
$password=$_POST["password"];


if(isset($_POST["signup-submit"])){
require 'dbh.php';

if (strlen($_POST["first-name"])==0||strlen($_POST["surname"])==0||strlen($_POST["email"])==0||strlen($_POST["username"])==0||strlen($_POST["password"])==0){
header("Location: ../Signup.php?signup=fail");
exit();
}

else{

if($_POST["password"]!==$_POST["confirm-password"]){
header("Location: ../Signup.php?signup=fail");
exit();
}

else{
$sql="SELECT uidUsers FROM users WHERE uidUsers=?";
$stmt=mysqli_stmt_init($conn);
mysqli_stmt_prepare($stmt,$sql);
mysqli_stmt_bind_param($stmt,"s",$username);
mysqli_stmt_execute($stmt);
mysqli_stmt_store_result($stmt);
$resultCheck=mysqli_stmt_num_rows($stmt);

if($resultCheck>0){
header("Location: ../Signup.php?signup=already");
exit();
}

else{
$key=rand(1, 1000000);
mail($email,"Key",$key);
$key=password_hash($key, PASSWORD_DEFAULT);
header("Location: ../Signupkey.php?username=".$username."&email=".$email."&key=".$key);
exit();
}
}
}
mysqli_stmt_close($stmt);
mysqli_close($conn);
}




if ($_GET["add"]=="database"){
require 'dbh.php';

$sql="INSERT INTO users (uidUsers, emailUsers, pwdUsers) VALUES (?, ?, ?)";
$stmt=mysqli_stmt_init($conn);
mysqli_stmt_prepare($stmt,$sql);
mysqli_stmt_bind_param($stmt,"sss",$username,$email,$password);
mysqli_stmt_execute($stmt);

mysqli_stmt_close($stmt);
mysqli_close($conn);

header("Location: ../Signup.php?signup=success");
exit();

}


?>
