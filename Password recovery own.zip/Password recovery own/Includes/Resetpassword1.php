<?php

$username=$_POST["username"];
$password=$_POST["password"];
$retypepassword=$_POST["retypepassword"];

if(isset($_POST["reset-password-submit"])){


require 'dbh.php';

if(!empty($username)){

if($password==$retypepassword and strlen($password)!==0){


$sql="UPDATE users SET pwdUsers=? WHERE uidUsers=?";
$stmt=mysqli_stmt_init($conn);
mysqli_stmt_prepare($stmt,$sql);
mysqli_stmt_bind_param($stmt,"ss",$password,$username);
mysqli_stmt_execute($stmt);

mysqli_stmt_close($stmt);
mysqli_close($conn);

header("Location: ../Login.php");
exit();

}

else{
header("Location: ../Resetpassword?password=invalid");
exit();
}

} 

else{
header("Location: ../Login.php?login=fail");
}

}

?>