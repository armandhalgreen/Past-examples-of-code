<?php
$dbServername ="localhost";
$dBUsername="root";
$dBPassword="";
$dBName="password_recovery_own";

$conn=mysqli_connect($dBServername,$dBUsername,$dBPassword,$dBName);

if(!$conn){
die("Connection failed:".mysqli_connect_error());

}
?>