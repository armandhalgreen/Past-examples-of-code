<html>

<body>
<h1> Homepage </h1><br><br>
</body>

<form action="Includes/Logout.php" method="post">
<button type="submit" name="logout-submit">Logout submit</button>
</form>

</body>

</html>