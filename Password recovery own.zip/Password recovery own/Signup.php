<html>

<body>
<h1> Signup up </h1><br><br>

<form action="Includes/Signup1.php" method="post">
<input type="text" name="first-name" placeholder="First name"><br>
<input type="text" name="surname" placeholder="Surname"><br>
<input type="text" name="email" placeholder="E-mail"><br>
<input type="text" name="username" placeholder="Username"><br>
<input type="password" name="password" placeholder="Password"><br>
<input type="password" name="confirm-password" placeholder="Confirm Password"><br>
<button type="submit" name="signup-submit">Sign up submit</button><br>
</form>

</body>
</html>

<?php
if ($_GET['signup']=='fail'){
echo 'Invalid first name, surname, email, username or password';
}

if ($_GET['signup']=='already'){
header("Location: Login.php");
}

if ($_GET['signup']=='success'){
header("Location: Login.php");
}
?>

<html>
<body>
<div>
<a href=Registrationform.php> Registrationform </a><br>
</div>

</body>
</html>
