<?php

$username=$_GET["username"];
$email=$_GET["email"];
$key=$_GET["key"];

?>

<html>

<body>
<h1> Signup up key </h1><br><br>

<form action="Includes/Signupkey1.php" method="post">
<input type="hidden" name="username" value="<?=$username?>"><br>
<input type="hidden" name="email" value="<?=$email?>"><br>
<input type="hidden" name="key" value="<?=$key?>"><br>
<input type="text" name="enteredkey" placeholder="key"><br>
<button type="submit" name="submitkey">Submit key</button><br>
</form>

</body>
</html>


<?php
if ($_GET["resend"]=="key"){

$username=$_GET["username"];
$email=$_GET["email"];
$key=$_GET["key"];

echo 'Invalid key';

echo '<form action="Includes/Signupkey1.php" method="post">
<input type="hidden" name="username" value="'.$username.'"><br>
<input type="hidden" name="email" value="'.$email.'"><br>
<button type="submit" name="resendkey">Resend key</button><br>
</form>';
}

?>

<html>
<body>
<div>
<a href=Registrationform.php> Registrationform </a><br>
</div>
</body>
</html>
