<html>

<body>
<h1> Login form </h1><br><br>

<form action="Includes/Login1.php" method="post">
<input type="text" name="username" placeholder="Username"><br>
<input type="password" name="password" placeholder="Password"><br>
<button type="submit" name="login-submit">Login</button>
</form>

<form action="Resetpassword.php" method="post">
<button type="submit" name="forgottenpassword-submit">Forgotten password</button>
</form>

</body>

</html>

<?php
if ($_GET['login']=='fail'){
echo 'Invalid username or password';
}

if ($_GET['login']=='success'){
header("Location: Homepage.php");
}
?>

<html>
<body>
<div>
<a href=Registrationform.php> Registrationform </a><br>
</div>

</body>
</html>
