
<html>

<body>
<h1> Reset password </h1><br><br>

<form action="Includes/Resetpassword1.php" method="post">
<input type="text" name="username" placeholder="Username"><br>
<input type="password" name="password" placeholder="Password"><br>
<input type="password" name="retypepassword" placeholder="Retype password"><br>
<button type="submit" name="reset-password-submit">Reset password submit</button>
</form>

</body>

</html>

<?php
if ($_GET['password']=='invalid'){
echo'Invalid password';
}

?>


<html>
<body>
<div>
<a href=Registrationform.php> Registrationform </a><br>
</div>

</body>
</html>
