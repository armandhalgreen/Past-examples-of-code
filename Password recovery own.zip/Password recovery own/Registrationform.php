<html>


<head>
<title> Registration form </title>
</head>

<body>
<h1> Registration form </h1><br><br>
<div>
<a href=Login.php> Login </a><br>
</div>
<div>
<a href=Signup.php> Signup </a><br>
</div>
</body>

</html>