#test function for expectation test
#test if all entires in the posterior data frame are numeric and lie between 0 and 1
#check if sun of each row is 1
test1_expectation <- function(posterior){
  test <- FALSE
  for (j in 1:ncol(posterior)) {
    for (i in 1:nrow(posterior)) {
      #test if all values are numeric and between 0 and 1 as they are probabilities
      if (!is.numeric(posterior[i,j]) || posterior[i,j] < 0 || posterior[i,j] > 1) return(FALSE)
      #sum of posterior values of the same fish should be 1
      if (posterior[i, 1] + posterior[i, 2] + posterior[i, 3] == 1) test <- TRUE
      else test <- FALSE
    }
  }
  return(test)
}

#Test if all estimates are positive and numeric
#and all the means and sigma should be positive, while 0 <= all lambdas <= 1
test1_estimates <- function(estimates){   
  for (i in 1:3){
    for (j in 1:3) {
      #return FALSE if any element in estimates is negative or non-numeric 
      if (estimates[i, j] < 0 || !is.numeric(estimates[i, j])) return(FALSE)
    }
    #return FALSE if any mean or sigma is negative or any lambda does not lie between 0 and 1
    if (all(estimates[i, 1:2] < c(0,0)) || estimates[i, 3] > 1 || estimates[i, 3] < 0) return (FALSE) 
  }
  #if the above conditions are not satisfied, return TRUE
  return(TRUE)
}

#Test if likelihood returns numeric element
#and the element should lie between -inf and 0 (finite)
test1_likelihood <- function(dataset, estimates){   
  likelihood <- likelihood(dataset, estimates)
  if (is.numeric(likelihood) && is.finite(likelihood)) return(TRUE)
}

#testing of convergence is boolean, if the posterior is N x k matrix of probabilities and if values of likelihood are finite
#also test if all return values are sensible using the above test functions
test1_teamEM <- function(dataset, epsilon = 10^(-8), maxit = 1000){
  test <- TRUE
  teamEM_list <- teamEM(dataset, epsilon, maxit)
  #return FALSE if converged is not a boolean variable 
  if (!is.logical(teamEM_list$converged)) return(FALSE)
  #if the estiates do not converge, then number of element in the likelihood vecto should equal to number of iterations (maxit)
  if (teamEM_list$converged == FALSE){
    if (length(teamEM_list$likelihood) != maxit) return(FALSE)
  }
  #return FALSE if posterior is not a N x k data frame 
  if (nrow(teamEM_list$posterior) != nrow(dataset) || ncol(teamEM_list$posterior) != ncol(dataset)) return(FALSE) 
  
  #check if estimates, inits and posterior returned are sensible by using test1_estimates 
  # and test1_expectation respectively
  if (test1_estimates(teamEM_list$estimates) && test1_estimates(teamEM_list$inits) && test1_expectation(teamEM_list$posterior)){
    #check if every element in the likelihood vector return is finite
    if (!all(is.finite(teamEM_list$likelihood))) return(FALSE)
  }else return(FALSE)
  return(TRUE)
}
