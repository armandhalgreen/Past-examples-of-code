# mt4113-base-assign2
# I confirm that this repository is the work of our team, except where clearly indicated

This is your team repository for Assignment 2 in MT4113. The data is contained in the file "FishLengths.RData". 
All the test functions are located in Test Functions.r.
Flow chart is located in Flow-chart.pdf.
Report is in report.pdf.
The teamEM function is in teamEM.R.
Contributions from each groupmate in contributions.docx.
